(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g=(g.com||(g.com = {}));g=(g.sensimity||(g.sensimity = {}));g=(g.ti||(g.ti = {}));g.parse = f()}})(function(){var define,module,exports;return (function e(t,n,r){function o(i,u){if(!n[i]){if(!t[i]){var a=typeof require=="function"&&require;if(!u&&a)return a.length===2?a(i,!0):a(i);if(s&&s.length===2)return s(i,!0);if(s)return s(i);var f=new Error("Cannot find module '"+i+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[i]={exports:{}};t[i][0].call(l.exports,function(e){var n=t[i][1][e];return o(n?n:e)},l,l.exports,e,t,n,r)}return n[i].exports}var i=Array.prototype.slice;Function.prototype.bind||Object.defineProperty(Function.prototype,"bind",{enumerable:!1,configurable:!0,writable:!0,value:function(e){function r(){return t.apply(this instanceof r&&e?this:e,n.concat(i.call(arguments)))}if(typeof this!="function")throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");var t=this,n=i.call(arguments,1);return r.prototype=Object.create(t.prototype),r.prototype.contructor=r,r}});var s=typeof require=="function"&&require;for(var u=0;u<r.length;u++)o(r[u]);return o})({1:[function(require,module,exports){
'use strict';

var push = require('./lib/push');

function init(appId, apiKey) {
    Ti.App.Properties.setString('com.sensimity.ti.parse_appId', Alloy.CFG.parse.appId);
    Ti.App.Properties.setString('com.sensimity.ti.parse_apiKey', Alloy.CFG.parse.apiKey);
}

function registerPush(channels) {
    push.registerPush(channels);
}

function updatePush(channels) {
    push.updatePush(channels);
}

module.exports = {
    "init": init,
    "registerPush": registerPush,
    "updatePush": updatePush
};
},{"./lib/push":6}],2:[function(require,module,exports){
'use strict';

var api = require('reste'),
    constant = require('./constants'),
    logger = require('./logger');

api.config({
    debug: false, // allows logging to console of ::REST:: messages
    autoValidateParams: false, // set to true to throw errors if <param> url properties are not passed
    timeout: 4000,
    url: "https://api.parse.com/1/",
    requestHeaders: {
        "X-Parse-Application-Id": Ti.App.Properties.getString('com.sensimity.ti.parse_appId', Alloy.CFG.parse.appId),
        "X-Parse-REST-API-Key": Ti.App.Properties.getString('com.sensimity.ti.parse_apiKey', Alloy.CFG.parse.apiKey),
        "Content-Type": "application/json"
    },
    methods: [{
        name: "addInstallation",
        post: "installations"
    }, {
        name: "updateInstallation",
        put: "installations/<objectId>"
    }],
    onError: function(e) {
        logger.info('There was an error accessing the API > ' + JSON.stringify(e.error));
    },
    onLoad: function(e, callback) {
        callback(e);
    }
});

function registerPush(params, success, error) {
    if (!Ti.Network.getOnline()) {
        logger.error('No push channels registration was issued, device is offline');
        return;
    }

    if (constant.OS_IOS) {
        api.addInstallation(params, success, error);
    } else if (constant.OS_ANDROID) {
        // Android Parse Integration
        // gittio install eu.rebelcorp.parse > 0.7
        var Parse = require('eu.rebelcorp.parse');
        Parse.start();

        Parse.addEventListener('notificationreceive', function(e) {
            params.notificationReceive && params.notificationReceive(e);
        });

        Parse.addEventListener('notificationopen', function(e) {
            params.notificationOpen && params.notificationOpen(e);
        });

        if (params.body.channels) {
            params.body.channels.map(function(channel) {
                logger.debug('Subscribing to channel: ' + channel);
                Parse.subscribeChannel(channel);
            });
        }

        success && success({
            'objectId': Parse.getObjectId()
        });
    }
}

function updatePush(params, success, error) {
    if (!Ti.Network.getOnline()) {
        logger.error('No push channels update was issued, device is offline');
        return;
    }
    api.updateInstallation(params, success, error);
}

exports.registerPush = registerPush;
exports.updatePush = updatePush;
},{"./constants":3,"./logger":5,"eu.rebelcorp.parse":undefined,"reste":undefined}],3:[function(require,module,exports){
exports.OS_ANDROID = (Ti.Platform.osname === 'android');
exports.OS_IOS = (Ti.Platform.name == "iPhone OS" || Ti.Platform.name == "ipad");

},{}],4:[function(require,module,exports){
module.exports = _.clone(Backbone.Events);
},{}],5:[function(require,module,exports){
'use strict';

var levels = ['info', 'warn', 'error', 'debug', 'trace'];

_.each(levels, function(level) {
   exports[level] = function(message) {
       log(message, level)
   }
});

function log(message, level) {
    Ti.API.log(level, message);
}

exports.log = log;
},{}],6:[function(require,module,exports){
var client = require('./client'),
    constant = require('./constants'),
    logger = require('./logger'),
    dispatcher = require('./dispatcher'),
    channels = require('./push/channels');

function timezone() {
    var dt = new Date();
    var tz = dt.toString();      // ends with (time zone name)
    tz = tz.replace(/^.*\(/,""); // Remove leading text through (
    tz = tz.replace(/\).*$/,""); // Remove trailing text from )
    return tz;
}

/**
 * Registers device for push notifications and then registers the device on Parse
 * with the default channels
 * @param {Array} channels
 */
function registerPush(_channels) {
    if (Ti.App.Properties.getString('com.sensimity.ti.parse_objectId', '') != '') {
        logger.info("Device already registered with objectId: " + Ti.App.Properties.getString('com.sensimity.ti.parse_objectId'));
        return;
    }

    logger.info("Registering device channels > " + JSON.stringify(_channels));

    channels.set(_channels);

    if (constant.OS_IOS) {

        // Check if the device is running iOS 8 or later
        if (parseInt(Ti.Platform.version.split(".")[0], 10) >= 8) {

            // Wait for user settings to be registered before registering for push notifications
            Ti.App.iOS.addEventListener('usernotificationsettings', function registerForPush() {

                // Remove event listener once registered for push notifications
                Ti.App.iOS.removeEventListener('usernotificationsettings', registerForPush);

                Ti.Network.registerForPushNotifications({
                    success : deviceTokenSuccess,
                    error : deviceTokenError,
                    callback : receivePush
                });
            });

            // Register notification types to use
            Ti.App.iOS.registerUserNotificationSettings({
                types : [Ti.App.iOS.USER_NOTIFICATION_TYPE_ALERT, Ti.App.iOS.USER_NOTIFICATION_TYPE_SOUND, Ti.App.iOS.USER_NOTIFICATION_TYPE_BADGE]
            });
        }
        // For iOS 7 and earlier
        else {
            Ti.Network.registerForPushNotifications({
                // Specifies which notifications to receive
                types : [Ti.Network.NOTIFICATION_TYPE_BADGE, Ti.Network.NOTIFICATION_TYPE_ALERT, Ti.Network.NOTIFICATION_TYPE_SOUND],
                success : deviceTokenSuccess,
                error : deviceTokenError,
                callback : receivePush
            });
        }

    } else if (constant.OS_ANDROID) {
        // android doesnt need device token for parse
        deviceTokenSuccess();
    }
}

function updatePush(_channels) {
    if (Ti.App.Properties.getString('com.sensimity.ti.parse_objectId', '') == '') {
        // incorrect usage of the API, update before registering. Fallback to register
        registerPush(_channels);
        return;
    }

    var updateParams = {};

    channels.set(_channels);

    if (constant.OS_IOS) {
        //logger.info("retrieved token!: " + e.deviceToken);

        //*******************************************************
        // REMOVE APPLICATION SPECIFIC CODE FROM LIBRARY
        // no alloy models code should be here!!
        updateParams = {
            objectId: Ti.App.Properties.getString('com.sensimity.ti.parse_objectId'),
            body : {
                "channels": channels.get(),
                "timeZone": timezone(),
                "appVersion" : Titanium.App.version
            }
        };
    } else {
        logger.debug("registering the android device for push");

        //*******************************************************
        // REMOVE APPLICATION SPECIFIC CODE FROM LIBRARY
        // no alloy models code should be here!!
        updateParams = {
            notificationReceive : receivePush,
            objectId: Ti.App.Properties.getString('com.sensimity.ti.parse_objectId'),
            body : {
                "channels": channels.get(),
                "deviceType" : "android"
            }
        };
    }

    client.updatePush(updateParams, function(_response) {
        channels.reset();
        logger.info("client.updatePush -  " + JSON.stringify(_response));
    }, function(_error) {
        channels.reset();
        logger.error("client.updatePush ERROR-  " + JSON.stringify(_error));
    });
}

// Process incoming push notifications for ios
function receivePush(e) {
    logger.info('Received push: ' + JSON.stringify(e));

    dispatcher.trigger("parse.push.received", e);
}

// Enable push notifications for this device
// Save the device token for subsequent API calls
function deviceTokenSuccess(e) {

    var registerParams = {};

    if (constant.OS_IOS) {
        logger.info("retrieved token!: " + e.deviceToken);

        //*******************************************************
        // REMOVE APPLICATION SPECIFIC CODE FROM LIBRARY
        // no alloy models code should be here!!
        registerParams = {
            body : {
                "channels": channels.get(),
                "deviceType" : "ios",
                "deviceToken" : e.deviceToken,
                "appIdentifier" : Ti.App.id,
                "appName" : Ti.App.name,
                "appVersion" : Ti.App.version,
                "timeZone": timezone(),
                "installationId" : Ti.Platform.createUUID()
            }
        };
    } else {
        logger.debug("registering the android device for push");

        //*******************************************************
        // REMOVE APPLICATION SPECIFIC CODE FROM LIBRARY
        // no alloy models code should be here!!
        registerParams = {
            notificationReceive : receivePush,
            body : {
                "channels": channels.get(),
                "deviceType" : "android"
            }
        };
    }

    client.registerPush(registerParams, function(_response) {
        channels.reset();

        if (!_.isUndefined(_response.objectId)) {
            logger.info("client.registerPush -  " + JSON.stringify(_response));
            Ti.App.Properties.setString('com.sensimity.ti.parse_objectId', _response.objectId);
        }

    }, function(_error) {
        channels.reset();
        logger.error("client.registerPush ERROR-  " + JSON.stringify(_error));
    });

}

function deviceTokenError(e) {
    logger.info('Failed to register for push notifications! ' + e.error);
}

module.exports = {
    registerPush : registerPush,
    updatePush : updatePush
};

},{"./client":2,"./constants":3,"./dispatcher":4,"./logger":5,"./push/channels":7}],7:[function(require,module,exports){
var channels = [''];

function set(_channels) {

    //assign channel
    if (!_.isUndefined(_channels)) {
        _channels = _channels instanceof Array ? _channels : [_channels];
        channels = channels.concat(_channels);
    }
}

function get() {
    return channels;
}

function reset() {
    channels = [''];
}

exports.set = set;
exports.get = get;
exports.reset = reset;
},{}]},{},[1])(1)
});